/**
  ******************************************************************************
  * @file    : 
  * @author  :
  * @version :
  * @date    :
  * @brief   :
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef PS2_IO__
#define PS2_IO__

/******************************************************************************
Includes
******************************************************************************/
#include "stm32f4xx_hal.h"
/******************************************************************************
Definitions
******************************************************************************/
/* PS2 Pin config */
#define PS2_SCK_PIN				GPIO_PIN_12
#define PS2_SCK_PORT			GPIOD
#define PS2_SCK_CLK_EN()		__GPIOD_CLK_ENABLE()  

#define PS2_SDA_PIN				GPIO_PIN_12
#define PS2_SDA_PORT            GPIOD
#define PS2_SDA_CLK_EN()        __GPIOD_CLK_ENABLE() 


/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
void PS2_Init(void);
void PS2_SendByte(uint8_t byte);
void PS2_ClkIsrHandler(void);


#endif /* PS2_IO__ */

/******************* (C) COPYRIGHT DUYNV  **********************END OF FILE****/
