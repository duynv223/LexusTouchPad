/**
  ******************************************************************************
  * @file    :
  * @author  :
  * @version :
  * @date    :
  * @brief   :
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/******************************************************************************
Includes
******************************************************************************/
#include "ps2_io.h"
/******************************************************************************
Private Definitions
******************************************************************************/
/* PS2 IO operation */
#define PS2_DAT_H()				HAL_GPIO_WritePin(PS2_DAT_PORT, PS2_DAT_PIN, GPIO_PIN_SET)
#define PS2_DAT_L()				HAL_GPIO_WritePin(PS2_DAT_PORT, PS2_DAT_PIN, GPIO_PIN_RESET)

#define PS2_DAT_DIR_I()\
	do{\
		GPIO_InitStruct.Pin = PS2_DAT_PIN;\
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;\
		HAL_GPIO_Init(PS2_DAT_PORT, &GPIO_InitStruct);\
	}while(0);\
	
#define PS2_DAT_DIR_O()\
	do{\
		GPIO_InitStruct.Pin = PS2_DAT_PIN;\
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;\
		HAL_GPIO_Init(PS2_DAT_PORT, &GPIO_InitStruct);\
	}while(0);\

#define PS2_WAIT_CLK_L()		while(HAL_GPIO_ReadPin(PS2_CLK_PORT, PS2_CLK_PIN) == GPIO_PIN_SET)
#define PS2_WAIT_CLK_H()		while(HAL_GPIO_ReadPin(PS2_CLK_PORT, PS2_CLK_PIN) == GPIO_PIN_RESET)

#define PS2_WAIT_DAT_L()		while(HAL_GPIO_ReadPin(PS2_DAT_PORT, PS2_DAT_PIN) == GPIO_PIN_SET)
#define PS2_WAIT_DAT_H()		while(HAL_GPIO_ReadPin(PS2_DAT_PORT, PS2_DAT_PIN) == GPIO_PIN_RESET)

#define PS2_CLK_MODE_IT_

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Private global variables
******************************************************************************/
GPIO_InitTypeDef  GPIO_InitStruct;

/******************************************************************************
Private function prototypes
******************************************************************************/

/******************************************************************************
Private functions
******************************************************************************/

/*****************************************************************************
* Function Name : 
* Description   : 
* Parameter     : None
* Return        : None
* Attention     : None
******************************************************************************/

void PS2_SDA_SetL()
{
	HAL_GPIO_WritePin(PS2_SDA_PORT, PS2_SDA_PIN, GPIO_PIN_RESET);
}

void PS2_SDA_SetH()
{
	HAL_GPIO_WritePin(PS2_SDA_PORT, PS2_SDA_PIN, GPIO_PIN_SET);
}

void PS2_SCK_SetL()
{
	HAL_GPIO_WritePin(PS2_SCK_PORT, PS2_SCK_PIN, GPIO_PIN_RESET);
}

void PS2_SCK_SetH()
{
	HAL_GPIO_WritePin(PS2_SCK_PORT, PS2_SCK_PIN, GPIO_PIN_SET);
}

void PS2_SDA_ModeI()
{
	GPIO_InitStruct.Pin = PS2_SDA_PIN; 
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
	GPIO_InitStruct.Pull  = GPIO_PULLUP;
	HAL_GPIO_Init(PS2_SDA_PORT, &GPIO_InitStruct); 
}

void PS2_SDA_ModeO()
{
	GPIO_InitStruct.Pin = PS2_SDA_PIN; 
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
	GPIO_InitStruct.Pull  = GPIO_PULLUP;
	HAL_GPIO_Init(PS2_SDA_PORT, &GPIO_InitStruct); 
}

void PS2_SDA_WaitL()
{
	while(HAL_GPIO_ReadPin(PS2_SDA_PORT, PS2_SDA_PIN) == GPIO_PIN_SET);
}

void PS2_SDA_WaitH()
{
	while(HAL_GPIO_ReadPin(PS2_SDA_PORT, PS2_SDA_PIN) == GPIO_PIN_RESET);
}

void PS2_SCK_WaitL()
{
	while(HAL_GPIO_ReadPin(PS2_SCK_PORT, PS2_SCK_PIN) == GPIO_PIN_SET);
}

void PS2_SCK_WaitH()
{
	while(HAL_GPIO_ReadPin(PS2_SCK_PORT, PS2_SCK_PIN) == GPIO_PIN_RESET);
}

void PS2_SCK_ModeI()
{
	GPIO_InitStruct.Pin = PS2_SCK_PIN; 
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
	GPIO_InitStruct.Pull  = GPIO_PULLUP;
	HAL_GPIO_Init(PS2_SCK_PORT, &GPIO_InitStruct); 
}

void PS2_SCK_ModeO()
{
	GPIO_InitStruct.Pin = PS2_SCK_PIN; 
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
	GPIO_InitStruct.Pull  = GPIO_PULLUP;
	HAL_GPIO_Init(PS2_SCK_PORT, &GPIO_InitStruct); 
}

void PS2_SCK_ModeIT()
{
	GPIO_InitStruct.Pin = PS2_SCK_PIN; 
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
	GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
	GPIO_InitStruct.Pull  = GPIO_PULLUP;
	HAL_GPIO_Init(PS2_SCK_PORT, &GPIO_InitStruct); 
	
	HAL_NVIC_SetPriority(EXTI0_IRQn, 2, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

void PS2_Delay(uint32_t n)
{
	while(n--);
}

void PS2_Init(void)
{
	/* Config IO */
	PS2_SCK_CLK_EN();
	PS2_SDA_CLK_EN();
	
	PS2_SCK_ModeI();
	PS2_SDA_ModeI();
}


void PS2_SendByte(uint8_t byte)
{
	uint8_t bitCnt = 0;
	uint8_t oddParity = 1;
	/* 1. Disable clk interrupt */
	PS2_SCK_ModeO();
	PS2_SDA_ModeO();
	/* 2. Bring bus to idle state */
	PS2_SCK_SetH();
	PS2_SDA_SetH();
	/* 3. Inhibited Bus */
	PS2_SCK_SetL();
	PS2_Delay(250);
	
	/* 4. Host Request-to-Send */
	PS2_SDA_SetL();
	PS2_Delay(2);
	PS2_SCK_ModeI();
	
	/* 5. Send byte */
	while(bitCnt < 8)
	{
		PS2_SCK_WaitL();
		if(byte & 0x01)
		{
			PS2_SDA_SetH();
			oddParity ^= 0x01;
		}
		else
		{
			PS2_SDA_SetL();
		}	
		byte = byte>>1;
	}
	
	/* 6. Send P bit*/
	PS2_SCK_WaitL();
	if(oddParity)
		PS2_SDA_SetH();
	else
		PS2_SDA_SetL();
		
	/* 7. Send S bit*/
	PS2_SCK_WaitL();
	PS2_SDA_SetL();
	
	/* 8. Get ACK */
	PS2_SCK_WaitL();
	PS2_SCK_WaitH();
	PS2_SCK_WaitL(); // now ACK valid
	
	PS2_SCK_WaitH();
	PS2_SDA_WaitH();
	
	/* 9. Enable clk interrupt */
	PS2_SCK_ModeIT();
}

void PS2_ClkIsrHandler(void);
/******************* (C) COPYRIGHT DUYNV  **********************END OF FILE****/
